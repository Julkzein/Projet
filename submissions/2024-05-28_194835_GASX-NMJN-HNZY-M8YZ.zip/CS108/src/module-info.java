module Projet {
    requires javafx.controls;
    requires java.net.http;
    requires java.datatransfer;

    exports ch.epfl.chacun;
    exports ch.epfl.chacun.gui;
}